__title__ = 'Django Form Surveys'
__version__ = '2.2.2'
__author__ = 'irfanpule'
